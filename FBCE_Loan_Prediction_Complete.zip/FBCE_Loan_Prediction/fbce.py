import math

def clamp(value, low=0.0, high=100.0):
    return max(low, min(high, float(value)))

def income_consistency(total_income, loan_amount):
    # Uses loan-to-income ratio as a simple academic consistency indicator.
    if total_income <= 0:
        return 0.0
    ratio = loan_amount / total_income
    # Lower requested-loan-to-income ratio gets a higher score.
    return clamp(100 * (1 - min(ratio / 10.0, 1.0)))

def debt_consistency(total_income, loan_amount):
    # The common Kaggle Loan Approval dataset does not contain an
    # explicit existing-debt column. Therefore this component uses
    # requested-loan burden as a proxy and is clearly labeled as such.
    if total_income <= 0:
        return 0.0
    burden = loan_amount / total_income
    return clamp(100 * (1 - min(burden / 8.0, 1.0)))

def employment_stability(self_employed, employment_years=None):
    # If years are supplied, use them; otherwise use the available
    # Self_Employed field from the common public dataset.
    if employment_years is not None:
        return clamp(30 + min(float(employment_years), 10) * 7)

    value = str(self_employed).strip().lower()
    if value in ("no", "not self employed", "salaried"):
        return 75.0
    if value in ("yes", "self employed"):
        return 65.0
    return 55.0

def credit_consistency(credit_history):
    try:
        value = float(credit_history)
    except Exception:
        value = 0.0
    return 90.0 if value >= 1 else 30.0

def repayment_capacity(total_income, loan_amount, loan_term_months, annual_interest_rate=10.0):
    if total_income <= 0 or loan_amount <= 0 or loan_term_months <= 0:
        return 0.0

    r = (annual_interest_rate / 100.0) / 12.0
    n = float(loan_term_months)

    if r == 0:
        emi = loan_amount / n
    else:
        emi = loan_amount * r * ((1 + r) ** n) / (((1 + r) ** n) - 1)

    emi_ratio = emi / total_income

    # Academic prototype scale: lower EMI-to-income ratio is more consistent.
    return clamp(100 * (1 - min(emi_ratio / 0.80, 1.0)))

def calculate_fbce(
    applicant_income,
    coapplicant_income,
    loan_amount,
    loan_term_months,
    credit_history,
    self_employed,
    annual_interest_rate=10.0,
    employment_years=None
):
    total_income = float(applicant_income) + float(coapplicant_income)
    loan_amount = float(loan_amount)

    scores = {
        "Income Consistency": income_consistency(total_income, loan_amount),
        "Debt Consistency": debt_consistency(total_income, loan_amount),
        "Employment Stability": employment_stability(self_employed, employment_years),
        "Credit Consistency": credit_consistency(credit_history),
        "Repayment Capacity": repayment_capacity(
            total_income, loan_amount, loan_term_months, annual_interest_rate
        ),
    }

    # Equal weights are a project-design choice, not a banking standard.
    fbce_score = sum(scores.values()) / len(scores)

    if fbce_score >= 80:
        risk = "High Consistency"
    elif fbce_score >= 60:
        risk = "Moderate Consistency"
    elif fbce_score >= 40:
        risk = "Low Consistency"
    else:
        risk = "Very Low Consistency"

    contradictions = []

    if total_income <= 0:
        contradictions.append("Reported total income is zero or unavailable.")
    elif loan_amount / total_income > 8:
        contradictions.append("Requested loan is very high relative to reported income.")

    if float(credit_history) < 1:
        contradictions.append("Credit history is marked as weak/unavailable.")

    return {
        "scores": scores,
        "fbce_score": round(fbce_score, 2),
        "risk_level": risk,
        "total_income": round(total_income, 2),
        "contradictions": contradictions,
    }
