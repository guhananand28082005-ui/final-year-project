from pathlib import Path
import warnings
warnings.filterwarnings("ignore")

import joblib
import pandas as pd
import numpy as np
import streamlit as st
import shap
import matplotlib.pyplot as plt

from fbce import calculate_fbce

BASE = Path(__file__).resolve().parent
MODEL_PATH = BASE / "models" / "fbce_model.pkl"
RESULT_PATH = BASE / "models" / "model_results.csv"

st.set_page_config(
    page_title="FBCE - Explainable Loan Prediction",
    page_icon="🏦",
    layout="wide"
)

st.title("Explainable Loan Prediction using FBCE")
st.caption("Financial Behaviour Consistency Engine — academic prototype")

@st.cache_resource
def load_model():
    if not MODEL_PATH.exists():
        return None
    return joblib.load(MODEL_PATH)

bundle = load_model()

st.sidebar.header("Project")
st.sidebar.write("FBCE combines machine-learning prediction, financial consistency checks and SHAP explanations.")
st.sidebar.info(
    "The FBCE score is a project-defined consistency indicator. "
    "It is not a banking credit score."
)

if bundle is None:
    st.warning("Model is not trained yet.")
    st.code("python train_model.py", language="bash")
    st.stop()

model = bundle["model"]
model_name = bundle["model_name"]

st.sidebar.success(f"Loaded model: {model_name}")

with st.form("loan_form"):
    st.subheader("Applicant Financial Details")

    c1, c2, c3 = st.columns(3)

    with c1:
        applicant_income = st.number_input(
            "Applicant Income", min_value=0.0, value=5000.0, step=500.0
        )
        coapplicant_income = st.number_input(
            "Co-applicant Income", min_value=0.0, value=1500.0, step=500.0
        )
        loan_amount = st.number_input(
            "Loan Amount", min_value=0.0, value=150.0, step=10.0,
            help="Use the same unit used by your training dataset."
        )

    with c2:
        loan_term = st.number_input(
            "Loan Term (months)", min_value=1, value=360, step=12
        )
        credit_history = st.selectbox(
            "Credit History", [1.0, 0.0],
            format_func=lambda x: "Good / Available" if x == 1.0 else "Weak / Unavailable"
        )
        gender = st.selectbox("Gender", ["Male", "Female"])
        married = st.selectbox("Married", ["Yes", "No"])

    with c3:
        dependents = st.selectbox("Dependents", ["0", "1", "2", "3+"])
        education = st.selectbox("Education", ["Graduate", "Not Graduate"])
        self_employed = st.selectbox("Self Employed", ["Yes", "No"])
        property_area = st.selectbox("Property Area", ["Urban", "Semiurban", "Rural"])

    submitted = st.form_submit_button("Predict Loan")

if submitted:
    # These columns match the common Kaggle Loan Approval dataset.
    input_df = pd.DataFrame([{
        "Gender": gender,
        "Married": married,
        "Dependents": dependents,
        "Education": education,
        "Self_Employed": self_employed,
        "ApplicantIncome": applicant_income,
        "CoapplicantIncome": coapplicant_income,
        "LoanAmount": loan_amount,
        "Loan_Amount_Term": loan_term,
        "Credit_History": credit_history,
        "Property_Area": property_area
    }])

    try:
        prediction = int(model.predict(input_df)[0])
        probability = float(model.predict_proba(input_df)[0][1])

        fbce = calculate_fbce(
            applicant_income=applicant_income,
            coapplicant_income=coapplicant_income,
            loan_amount=loan_amount,
            loan_term_months=loan_term,
            credit_history=credit_history,
            self_employed=self_employed
        )

        st.divider()
        st.subheader("Prediction Result")

        r1, r2, r3 = st.columns(3)
        with r1:
            st.metric("Loan Prediction", "APPROVED" if prediction == 1 else "REJECTED")
        with r2:
            st.metric("Approval Probability", f"{probability * 100:.2f}%")
        with r3:
            st.metric("FBCE Score", f"{fbce['fbce_score']:.2f}/100")

        st.write(f"**Consistency Level:** {fbce['risk_level']}")

        left, right = st.columns(2)

        with left:
            st.subheader("FBCE Components")
            score_df = pd.DataFrame(
                list(fbce["scores"].items()),
                columns=["Component", "Score"]
            )
            st.dataframe(score_df, use_container_width=True, hide_index=True)
            st.bar_chart(score_df.set_index("Component"))

        with right:
            st.subheader("Financial Consistency Checks")
            if fbce["contradictions"]:
                for item in fbce["contradictions"]:
                    st.warning(item)
            else:
                st.success("No major project-defined financial consistency contradiction detected.")

            st.write(f"**Total Income:** {fbce['total_income']:.2f}")

        st.divider()
        st.subheader("SHAP Explanation")

        try:
            preprocessor = model.named_steps["preprocessor"]
            estimator = model.named_steps["model"]
            transformed = preprocessor.transform(input_df)

            feature_names = preprocessor.get_feature_names_out()

            if model_name in ["Random Forest", "XGBoost", "LightGBM"]:
                explainer = shap.TreeExplainer(estimator)
                shap_values = explainer.shap_values(transformed)

                if isinstance(shap_values, list):
                    values = shap_values[1][0]
                else:
                    values = np.asarray(shap_values)
                    if values.ndim == 3:
                        values = values[0, :, 1]
                    elif values.ndim == 2:
                        values = values[0]

                explanation_df = pd.DataFrame({
                    "Feature": feature_names,
                    "SHAP Value": values
                })
            else:
                # Linear-model explanation.
                background = np.zeros((1, transformed.shape[1]))
                explainer = shap.LinearExplainer(estimator, background)
                shap_values = explainer.shap_values(transformed)
                values = np.asarray(shap_values)
                if values.ndim == 2:
                    values = values[0]

                explanation_df = pd.DataFrame({
                    "Feature": feature_names,
                    "SHAP Value": values
                })

            explanation_df["Absolute"] = explanation_df["SHAP Value"].abs()
            explanation_df = explanation_df.sort_values("Absolute", ascending=False).head(10)

            st.dataframe(
                explanation_df[["Feature", "SHAP Value"]],
                use_container_width=True,
                hide_index=True
            )

            fig, ax = plt.subplots(figsize=(9, 5))
            plot_df = explanation_df.sort_values("SHAP Value")
            ax.barh(plot_df["Feature"], plot_df["SHAP Value"])
            ax.axvline(0, linewidth=1)
            ax.set_xlabel("SHAP contribution")
            ax.set_title("Top SHAP Feature Contributions")
            fig.tight_layout()
            st.pyplot(fig)

            positive = explanation_df[explanation_df["SHAP Value"] > 0]
            negative = explanation_df[explanation_df["SHAP Value"] < 0]

            p1, p2 = st.columns(2)
            with p1:
                st.write("**Positive contributors**")
                if len(positive):
                    for _, row in positive.iterrows():
                        st.write(f"• {row['Feature']}: +{row['SHAP Value']:.4f}")
                else:
                    st.write("No positive contributors in the displayed top features.")

            with p2:
                st.write("**Negative contributors**")
                if len(negative):
                    for _, row in negative.iterrows():
                        st.write(f"• {row['Feature']}: {row['SHAP Value']:.4f}")
                else:
                    st.write("No negative contributors in the displayed top features.")

        except Exception as e:
            st.error("SHAP explanation could not be generated for this model/input.")
            st.code(str(e))

        st.divider()
        st.subheader("Decision Summary")

        if prediction == 1:
            st.success(
                "The machine-learning model predicts approval. "
                "Review the FBCE score and SHAP factors before treating the output as decision support."
            )
        else:
            st.error(
                "The machine-learning model predicts rejection. "
                "Review the FBCE score and SHAP factors to understand the major contributing features."
            )

        st.caption(
            "For academic demonstration only. This prototype does not provide a real banking decision."
        )

    except Exception as e:
        st.error("Prediction failed.")
        st.code(str(e))
        st.info(
            "Make sure your dataset uses the same feature names as the common "
            "Loan Approval Prediction dataset."
        )
